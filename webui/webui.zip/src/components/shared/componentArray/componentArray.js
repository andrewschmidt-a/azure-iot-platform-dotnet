// Copyright (c) Microsoft. All rights reserved.

export const ComponentArray = ({ children }) => children;
