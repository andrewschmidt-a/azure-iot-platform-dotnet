// Copyright (c) Microsoft. All rights reserved.

export * from './deviceDelete.container';
export * from './deviceDelete';
