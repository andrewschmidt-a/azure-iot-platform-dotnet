// Copyright (c) Microsoft. All rights reserved.

export * from './createTenantBtn.container';
