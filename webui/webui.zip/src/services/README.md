Services
==========
The services folder contains all the files related to making service calls.
With the exception of the `httpClient` (which contains the logic for making
ajax request and retrying errors) each file corresponds to its own endpoint.
The use of the term "services" are reminiscent of the Angular use of the term.
