header() {
    echo -e "\n### $1"
}

error() {
    echo -e "$1"
}
