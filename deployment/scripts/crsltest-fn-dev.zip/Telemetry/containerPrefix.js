var containerPrefix = "telemetry";

module.exports = containerPrefix;
