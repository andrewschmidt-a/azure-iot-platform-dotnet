const sendMessages = require('../Shared/messageFlow');

const containerPrefix = require('./containerPrefix');

module.exports = async function (context, eventHubMessages) {
    await sendMessages(containerPrefix, context, eventHubMessages, (message, index) => {
        // no message processing is necessary for this function
        var messageProperties = context.bindingData.systemPropertiesArray[index];
        // add some meta data to the event hub message before writing
        message["_deviceId"] = messageProperties["iothub-connection-device-id"];

        // process the date in readable format and ms since 1970-01-01
        date = new Date(messageProperties["iothub-enqueuedtime"]);
        message["_dateTimeReceived"] = date.toString();  // readable format
        message["_timeReceived"] = date.getTime();  // since 1970-01-01

        message["_schema"] = "message";
        return message;
    });
};

