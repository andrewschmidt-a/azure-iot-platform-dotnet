var cosmosConfig = {
    connectionString: process.env.CosmosDbConnectionString,
    database: {
        id: process.env.CosmosDbDatabaseName 
    },
    container: {
        options: {
            offerThroughput: 400
        },
        partitionKey: {
            kind: "Hash",
            paths: ["/_deviceId"]
        }
    }
}

module.exports = cosmosConfig;