var { generateContainerId, createCosmosDoc, cosmosWriterError } = require('./cosmosWriter')


async function messageFlow(containerPrefix, context, message, index, preProcess) {
    var flowResponse = {
        success: false,
        message: message,
        index: index,
        containerId: "",
        tenant: "",
        error: ""
    }; 
    try {
        var processedMessage = preProcess(message, index);
        flowResponse.message = processedMessage;
    }
    catch (error) {
        context.log(`An error occurred during the provided Message Preprocessing Function: ${error.message}`);
        flowResponse.error = error.message;
        return flowResponse;
    }
    // get the tenant from the context
    try {
        var tenant = context.bindingData.propertiesArray[index].tenant;
        flowResponse.tenant = tenant;
    }
    catch (error) {
        context.log(`An error occurred while getting the tenant from context.bindingData.propertiesArray[${index}].`);
        flowResponse.error = error.message;
        return flowResponse;

    }
    var containerId = generateContainerId(containerPrefix, tenant);
    flowResponse.containerId = containerId;
    try {
        await createCosmosDoc(context, processedMessage, containerId);
    }
    catch (error) {
        if (error != cosmosWriterError){
            context.log(`An unhandled error occurred while attempting to create the message: ${error.message}`);
        }
        flowResponse.error = error.message;
        return flowResponse;
    }
    flowResponse.success = true;
    return flowResponse;
}

module.exports = async function(containerPrefix, context, eventHubMessages, preProcessMessage) {
    var failedMessages = [];  // a list of failed messages - these are logged at the end of the funciton
    for (let [index, message] of eventHubMessages.entries()) {
        try {
            var flowResponse = await messageFlow(containerPrefix, context, message, index, preProcessMessage);
            if (!flowResponse.success) {
                // The response from messageFlow will return a document with a success attribute - if it is false, add to failedMessages array
                failedMessages.push(flowResponse);
            }
        }
        catch (error) {
            // if an unhandled exception occurs during messageFlow - add a failed message with all available info
            var unhandledMessage = `An unhandled error occurred during the message flow for message ${index}: ${error.message}`;
            failedMessages.push({
                success: false,
                message: message,
                index: index,
                containerId: "",
                tenant: "",
                error: unhandledMessage
            });
        }
    }

    // After attempting to send all messages, report failures
    if (failedMessages.length > 0) {
        context.log(`The following message(s) could not be created in CosmosDb:`);
        failedMessages.forEach((message) => {
            context.log(message);
        });
        // ensures the function is marked as a failure - and that failed messages are reported in the log
        throw Error("Unable to send all messages successfully.");
    }
};