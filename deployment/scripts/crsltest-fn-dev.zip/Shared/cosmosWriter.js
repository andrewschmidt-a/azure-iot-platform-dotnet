const Cosmos = require('@azure/cosmos');

const cosmosConfig = require('./cosmosConfig');

const client = new Cosmos.CosmosClient(cosmosConfig.connectionString);
const databaseId = cosmosConfig.database.id;
const partitionKey = cosmosConfig.container.partitionKey;
const containerOptions = cosmosConfig.container.options;

const cosmosWriterError = {
    name: "cosmosWriterError",
    level: "High",
    message: "Unable to create the requested document in CosmosDb.",
    toString: function(){return `${this.name}: ${this.message}`;}
};

function generateContainerId(containerPrefix, tenant) {
    return `${containerPrefix}-${tenant}`;
}

async function createCosmosDoc(context, doc, containerId) {
    try {
        await client.database(databaseId).containers.createIfNotExists({ id: containerId, partitionKey }, containerOptions);
    }
    catch (containerError) {
        context.log(`An Error occurred during createIfNotExists for containerId ${containerId}: ${containerError.message}`);
        throw cosmosWriterError;
    }

    try {
        await client.database(databaseId).container(containerId).items.create(doc);
    }
    catch (createError) {
        context.log(`Unable to create message in ${containerId}: ${createError.message}`);
        throw cosmosWriterError;
    }
}

module.exports = { generateContainerId, createCosmosDoc, cosmosWriterError };