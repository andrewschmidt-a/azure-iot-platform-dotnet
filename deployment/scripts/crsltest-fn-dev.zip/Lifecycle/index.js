const sendMessages = require('../Shared/messageFlow');

const containerPrefix = require('./containerPrefix');

module.exports = async function (context, eventHubMessages) {
    await sendMessages(containerPrefix, context, eventHubMessages, (message, index) => {
        // no message processing is necessary for this function
        return message;
    });
};
