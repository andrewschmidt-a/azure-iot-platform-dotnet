var containerPrefix = "lifecycle";

module.exports = containerPrefix;
